"""
The data package contains game data stored in text, csv or other files.
"""